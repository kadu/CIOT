#ifndef SENDCIOT_H_
#define SENDCIOT_H_

#include <Arduino.h>

class SendCiot{
	public:
		//definition of a public class that will form a JSON from the array sent
		String send(String array[][2], int elements, String apikey, String device);
};

#endif
